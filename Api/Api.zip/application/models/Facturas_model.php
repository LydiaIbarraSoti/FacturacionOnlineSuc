<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Facturas_model extends CI_Model {

    public function consultar_facturas($fecha_inicio, $fecha_final) {
        $this->db->select("FECHA_HR_CREACION as fecha_factura, RFC_EMISOR as rfc_emisor, RFC_RECEPTOR as rfc_receptor, RAZON_SOCIAL_RECEPTOR as razon_social_receptor, DOMICILIO_FISCAL_RECEPTOR as domicilio_fiscal_receptor, REGIMEN_FISCAL_RECEPTOR as regimen_fiscal_receptor, CERT_SAT as cert_sat, CERT_EMISOR as cert_emisor, FECHA_TIM as fecha_tim, UUID as uuid, SUBTOTAL as subtotal, TOTAL as total, SERIE as serie, FOLIO as folio, METODO_PAGO as metodo_pago, FORMA_PAGO as forma_pago, USO_CFDI as uso_cfdi, RUTA_XML as ruta_xml");
        $this->db->from('REPOSITORIOS');
        $this->db->where('DATE(FECHA_HR_CREACION) >=', $fecha_inicio);
        $this->db->where('DATE(FECHA_HR_CREACION) <=', $fecha_final);
        $query = $this->db->get();

        $facturas = $query->result_array();

        // Añadir el archivo XML
        foreach ($facturas as &$factura) {
            $factura['archivo'] = file_get_contents($_SERVER['DOCUMENT_ROOT'] . $factura['ruta_xml']);
        }

        return $facturas;
    }
}
